import React from 'react';
import {Header, Navbar} from "./components"
const App = () => {
  return (
  <>
    <Header/>
  </>
  )
}

export default App;